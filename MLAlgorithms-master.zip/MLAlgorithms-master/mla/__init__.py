# coding:utf-8
# copyright: (c) 2016 by Artem Golubin
# license: MIT, see LICENSE for more details.
